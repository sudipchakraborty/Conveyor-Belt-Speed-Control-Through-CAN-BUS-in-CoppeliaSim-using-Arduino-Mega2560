﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO.Ports;

namespace Tools
{
    public static class rs232Sync
    {
            public static String port_name = "";
            public static int baud_rate = 0;
            public static SerialPort sp;
            public static byte[] byteBfr;
            public static int bfrptr_write = 0;
            public static int bfrptr_read = 0;
            public static bool packet_received = false;

            public static String strBfr;
            public static byte[] bBfr = new byte[9];
            public static byte[] bBfr_temp = new byte[9];


            public static String cmd = "";
            public static int receive_count = 0;

            public static String bfr_rx;
            public static int receive_line_count = 0;
            public static int ptr_rx = 0;
            public static bool created = false;
            public static bool IsOpen = false;

            public static int Time_Out_Reg=1000;
                   static int Time_Out_Val=100;
        //_____________________________________________________________________________________________________________________
        public static bool open(String p_name, int b_rate)
            {
                port_name = p_name;
                baud_rate = b_rate;

                try
                {
                    sp = new SerialPort(port_name, baud_rate, Parity.None, 8, StopBits.One);
                    sp.ReadTimeout = 5000;
                    sp.WriteTimeout = 5000;
             //       sp.DataReceived += new SerialDataReceivedEventHandler(port_DataReceived);
                    if (!sp.IsOpen)
                        sp.Open();
                    sp.DiscardInBuffer();
                    created = true;
                    IsOpen = true;
                    return true;
                }
                catch (Exception ex)
                {
                    if (sp.IsOpen)
                    {
                        sp.Close();
                        sp.DiscardInBuffer();
                        created = false;
                        IsOpen = false;
                        return false;
                    }
                }
                return false;
            }
        //_______________________________________________________________________________________________
        public static string send_receive(string cmd)
        {
            byte[] b = Encoding.ASCII.GetBytes(cmd);

            int intBuffer;
            packet_received = false;
            Time_Out_Reg = Time_Out_Val;
            sp.DiscardInBuffer();
            sp.DiscardOutBuffer();
            intBuffer = sp.BytesToRead;
            try
            {
                for (int i = 0; i < b.Count(); i++)
                {
                    sp.Write(b, i, 1);
                    //     System.Threading.Thread.Sleep(5);
                }
                ///////////////
                while (sp.BytesToRead == 0)
                {
                    if (Time_Expired())
                    {
                        return "";
                    }
                }
                ////////////////////////////////
                System.Threading.Thread.Sleep(100);
                intBuffer = sp.BytesToRead;
                byteBfr = new byte[intBuffer];
                sp.Read(byteBfr, 0, intBuffer);
                packet_received = true;
                sp.DiscardInBuffer();
                return BitConverter.ToString(byteBfr);
            }
            catch (Exception ex)
            {
                String s = ex.ToString();
            }

            return "";
        }

        public static byte[] send_receive_bytes(string cmd)
        {
            byte[] b = Encoding.ASCII.GetBytes(cmd);

            int intBuffer;
            packet_received = false;
            Time_Out_Reg = Time_Out_Val;
            sp.DiscardInBuffer();
            sp.DiscardOutBuffer();
            intBuffer = sp.BytesToRead;
            try
            {
                for (int i = 0; i < b.Count(); i++)
                {
                    sp.Write(b, i, 1);
                    //     System.Threading.Thread.Sleep(5);
                }
                ///////////////
                while (sp.BytesToRead == 0)
                {
                    if (Time_Expired())
                    {
                        return null;
                    }
                }
                ////////////////////////////////
                System.Threading.Thread.Sleep(100);
                intBuffer = sp.BytesToRead;
                byteBfr = new byte[intBuffer];
                sp.Read(byteBfr, 0, intBuffer);
                packet_received = true;
                sp.DiscardInBuffer();
                return  byteBfr;
            }
            catch (Exception ex)
            {
                String s = ex.ToString();
            }
            return null;
        }

        public static int send_receive_int(string cmd)
        {
            byte[] b = Encoding.ASCII.GetBytes(cmd);

            int intBuffer;
            packet_received = false;
            Time_Out_Reg = Time_Out_Val;
            sp.DiscardInBuffer();
            sp.DiscardOutBuffer();
            intBuffer = sp.BytesToRead;
            try
            {
                for (int i = 0; i < b.Count(); i++)
                {
                    sp.Write(b, i, 1);
                    //     System.Threading.Thread.Sleep(5);
                }
                ///////////////
                while (sp.BytesToRead == 0)
                {
                    if (Time_Expired())
                    {
                        return 0;
                    }
                }
                ////////////////////////////////
                System.Threading.Thread.Sleep(100);
                intBuffer = sp.BytesToRead;
                byteBfr = new byte[intBuffer];
                sp.Read(byteBfr, 0, intBuffer);
                packet_received = true;
                sp.DiscardInBuffer();

                char[] characters = System.Text.Encoding.ASCII.GetChars(byteBfr);
                string val = new string(characters);
                int k = Convert.ToInt16(val);
                return k;
            }
            catch (Exception ex)
            {
                String s = ex.ToString();
            }
            return 0;
        }
       
        public static string send_receive(string cmd, string receive_timeOut)
        {
            byte[] b = Encoding.ASCII.GetBytes(cmd);

            int intBuffer;
            packet_received = false;
            Time_Out_Reg = Time_Out_Val;
            sp.DiscardInBuffer();
            sp.DiscardOutBuffer();
            intBuffer = sp.BytesToRead;
            try
            {
                for (int i = 0; i < b.Count(); i++)
                {
                    sp.Write(b, i, 1);
                    //     System.Threading.Thread.Sleep(5);
                }
                ///////////////
                Time_Out_Reg = Convert.ToInt16(receive_timeOut);
                while (sp.BytesToRead == 0)
                {
                    if (Time_Expired())
                    {
                        return "";
                    }
                }
                ////////////////////////////////
                System.Threading.Thread.Sleep(100);
                intBuffer = sp.BytesToRead;
                byteBfr = new byte[intBuffer];
                sp.Read(byteBfr, 0, intBuffer);
                packet_received = true;
                sp.DiscardInBuffer();
                return BitConverter.ToString(byteBfr);
            }
            catch (Exception ex)
            {
                String s = ex.ToString();
            }

            return "";
        }




        public static void Byte_Write(byte[] b, int count)
            {
                int intBuffer;
                packet_received = false;
                Time_Out_Reg = Time_Out_Val;
                sp.DiscardInBuffer();
                sp.DiscardOutBuffer();
                intBuffer = sp.BytesToRead;
            try
                {
                    for (int i = 0; i < count; i++)
                    {
                        sp.Write(b, i, 1);
                   //     System.Threading.Thread.Sleep(5);
                    }
                    ///////////////
                    while (sp.BytesToRead == 0)
                    {
                        if (Time_Expired())
                        {
                            return;
                        }
                    }
                ////////////////////////////////
                System.Threading.Thread.Sleep(100);
                intBuffer = sp.BytesToRead;
                byteBfr = new byte[intBuffer];
                sp.Read(byteBfr, 0, intBuffer);
                packet_received = true;
                sp.DiscardInBuffer();
            }
            catch (Exception ex)
            {
                String s = ex.ToString();
                }
            }
        //_______________________________________________________________________________________________
       private static bool Time_Expired()
        {
            if(Time_Out_Reg > 0)
            {
                Time_Out_Reg--;
                System.Threading.Thread.Sleep(1);
                return false;
            }
            else
            {
                return true; 
            }     
        }
       
        public static void disconnect()
        {
            Dispose();
        }

        public static void close()
        {
            Dispose();
        }

        public static void Dispose()
            {
                if (sp.IsOpen)
                {
                    try
                    {
                        sp.DiscardInBuffer();
                        sp.Dispose();
                        sp.Close();
                    }
                    catch (Exception ex)
                    {
                        String s = ex.ToString();
                    }
                    finally
                    {
                        created = false;
                        IsOpen = false;
                    }
                }
                sp.Dispose();
            }
            //_____________________________________________________________________________________________________________________


    }// class
}// namespace
