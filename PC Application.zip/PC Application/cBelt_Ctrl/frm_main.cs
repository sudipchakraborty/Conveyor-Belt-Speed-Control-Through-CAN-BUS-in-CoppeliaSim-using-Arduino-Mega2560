﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Threading;

using Tools;

namespace cBelt_Ctrl
{
    public partial class frm_main : Form
    {
       tcp_server_CoppeliaSim server=new tcp_server_CoppeliaSim(6000);
       Thread th = new Thread(Read_Serial_Port);
       static bool stop = false;
        static int adc_val = 0;

        public frm_main()
        {
            InitializeComponent();
        }

        private void hs_speed_Scroll(object sender, ScrollEventArgs e)
        {
            txt_speed.Text =hs_speed.Value.ToString();
        }

        private void frm_main_Load(object sender, EventArgs e)
        {
            txt_adc.Select(0, 0);
            timer_fetch_data.Enabled = true;
            
        }

        private void btn_connect_Click(object sender, EventArgs e)
        {
            if(rs232Sync.open(txt_port.Text, Convert.ToInt16(txt_baud_rate.Text)))
            {
                txt_msg.Text = "Connected";
                timer_fetch_data.Enabled = true;
                th.Start();
            }
            
        }

        private void timer_fetch_data_Tick(object sender, EventArgs e)
        {
            if(server.cmd_received)
            {
                server.cmd_received=false;
                server.cmd =txt_speed.Text;
                server.cmd_send = true;
            }
            //////////////////////////////////
            if (rbtn_external.Checked)
            {            
                txt_adc.Text = adc_val.ToString();  
                txt_speed.Text= adc_val.ToString();
            }
            ///////////////////////////////////
            if (rbtn_slider.Checked)
            {
                txt_speed.Text = hs_speed.Value.ToString();
                txt_adc.Text = "";
            }
            /////////////////////////////////////
        

    }

        private void btn_disconnect_Click(object sender, EventArgs e)
        {
            timer_fetch_data.Stop();
            rs232Sync.close();
            txt_msg.Text = "PORT Disconnected";
        }

        private static void Read_Serial_Port()
        {           
            while (!stop)
            {
              adc_val= rs232Sync.send_receive_int("v");
                Thread.Sleep(100);
            }
        }

        private void frm_main_FormClosing(object sender, FormClosingEventArgs e)
        {
            stop = true;
        }
    }
}
