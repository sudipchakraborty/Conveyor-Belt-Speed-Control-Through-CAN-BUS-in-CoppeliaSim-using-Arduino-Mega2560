﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Net;
using System.Net.Sockets;
using System.Collections;
using System.IO;
using System.Threading;

namespace Tools
{
    class tcp_server
    {
        TcpListener server=null;
        public bool started = false;
        public bool connected;
        public int port;
        Thread srv;
        public bool exit = false;

        public bool cmd_received = false;
        public bool cmd_send = false;
        public string cmd = "";

        public string FSM = "";
        public byte[] bfr_RX;
        public byte[] bfr_TX = new byte[1024];
        public int Send_Count;
        //________________________________________________________________________________________________
        public tcp_server()
        {
            connected = false;
        }
        //________________________________________________________________________________________________
        public tcp_server(int port)
        {
            this.port = port;
            connected = false;

            server = new TcpListener(IPAddress.Any, port);
            server.Start();
            started = true;
            FSM = "Waiting_for_Client";

            srv = new Thread(active_listen);
            srv.Start();
        }
        //________________________________________________________________________________________________ 
        public void close()
        {
            try
            {
                server.Stop();
                exit = true;
            }catch(Exception ex)
            {
                string s = ex.ToString();
            }         
        }
        //________________________________________________________________________________________________
        private void active_listen()
        {
            TcpClient client;
            NetworkStream ns = null;
            byte[] msg = new byte[1024];
           // FSM = "init";

            while (!exit)
            {               
                ///////////////////////
                switch (FSM)
                {
                    case "init":
                        try
                        {
                            server = new TcpListener(IPAddress.Any, port);
                            server.Start();
                            started = true;
                            FSM = "Waiting_for_Client";
                        }
                        catch(Exception ex)
                        {
                            string s = ex.ToString();
                            started = false;
                            Thread.Sleep(1000);
                        }
                        break;
                    ///////////////
                    case "Waiting_for_Client":
                        try
                        {
                            client = server.AcceptTcpClient();
                            ns = client.GetStream();
                        }catch(Exception ex)
                        {

                        }
                  //      FSM = "Send_Hello";
                        FSM = "Reading Data";
                        break;
                    ////////////////////////////
                    case "Send_Hello":
                        try
                        {
                            byte[] hello = Encoding.ASCII.GetBytes("\r\n<hello>\r\n");
                            ns.Write(hello, 0, hello.Length);
                        }catch(Exception ex)
                        {


                        }
                        FSM = "Reading Data";
                        break;
                    //////////////////////////////
                    case "Reading Data":
                        Int32 k = 0;

                        try
                        {
                            k = ns.Read(msg, 0, msg.Length);   //the same networkstream reads the message sent by the client
                        }
                        catch( Exception ex)
                        {
                            string s = ex.ToString();
                        }

                        if (k == 0)
                        {
                            FSM = "Waiting_for_Client";
                            break;
                        }
                        else
                        {
                            cmd += Encoding.ASCII.GetString(msg, 0, k);
                            bfr_RX = msg;    //Encoding.ASCII.GetBytes(cmd);
                            // ns.Write(b, 0, b.Length);

                          //  if (cmd.Contains('\r'))
                           // {
                                this.cmd_received = true;
                                FSM = "Waiting_for_user_response";
                          //  }
                        }
                        
                        break;
                    ////////////////////
                    case "Waiting_for_user_response":
                        if (cmd_send)
                        {
                            cmd_send = false;
                            byte[] b = Encoding.ASCII.GetBytes("aa");
                            try
                            {
                               // ns.Write(bfr_TX, 0, Send_Count); 
                                ns.Write(b, 0, b.Length);
                            }
                            catch(Exception ex)
                            {
                                string s = ex.ToString();
                            }
                            cmd = "";
                            FSM = "Reading Data";
                        }
                        break;
                    ///////////////////////
                    default: break;
                }// switch-case
            }// while(true)








            //while (!exit)
            //{
            //    try
            //    {
            //        server = new TcpListener(IPAddress.Any, 502);
            //        server.Start();  // this will start the server
            //        client = server.AcceptTcpClient();
            //        ns = client.GetStream();
            //        hello = utility.Get_Bytes_from_string("\r\n<hello>\r\n");
            //        ns.Write(hello, 0, hello.Length);
            //    }catch(Exception ex)
            //    {
            //        return;
            //    }

            //    while (!exit)
            //    {
            //        try
            //        {
            //            byte[] msg = new byte[1024];
            //            if(client.Connected) 
            //            {
            //              Int32 k=  ns.Read(msg, 0, msg.Length);   //the same networkstream reads the message sent by the client

            //                if(k==0)
            //                {
            //                    ns.Close();
            //                    client.Close();
            //                    client = server.AcceptTcpClient();

            //                    ns = client.GetStream();
            //                    ns.Write(hello, 0, hello.Length); 
            //                }
            //                else
            //                {
            //                    cmd += Encoding.ASCII.GetString(msg, 0, k);
            //                }

            //              if(cmd.Contains("\r"))
            //                {
            //                    this.cmd_received = true;
            //                    while (!cmd_send);
            //                    byte[] b = utility.Get_Bytes_from_string(cmd);
            //                    ns.Write(b, 0, b.Length);
            //                    cmd_send = false;
            //                    //ns.Close();
            //                    //ns = client.GetStream();
            //                    cmd = "";
            //                    break;
            //                }                         
            //            }
            //            else
            //            {
            //                client = server.AcceptTcpClient();
            //            }



            //            string sk = "";

            //        }
            //        catch (Exception ex)
            //        {
            //            string s = ex.ToString();
            //            //close();
            //            //server = new TcpListener(IPAddress.Any, port);
            //            //server.Start();
            //        }

            //    }
            //}// outer loop
        }
        //________________________________________________________________________________________________
 
       






    }//class tcp_client
}// namespace Formation_Charger.Tools
