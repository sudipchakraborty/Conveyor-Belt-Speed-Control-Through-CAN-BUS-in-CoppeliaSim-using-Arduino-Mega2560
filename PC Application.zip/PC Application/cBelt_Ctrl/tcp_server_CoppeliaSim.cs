﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Net;
using System.Net.Sockets;
using System.Collections;
using System.IO;
using System.Threading;

namespace Tools
{
    class tcp_server_CoppeliaSim
    {
        TcpListener server=null;
        public bool connected;
        public int port;
        Thread srv;
        public bool exit = false;

        public bool cmd_received = false;
        public bool cmd_send = false;
        public string cmd = "";

        public string FSM = "";

        public tcp_server_CoppeliaSim(int port)
        {
            this.port = port;
            connected = false;
            srv = new Thread(active_listen);
            srv.Start();
        }
        //________________________________________________________________________________________________ 
        public void close()
        {
            try
            {
                server.Stop();
            }catch(Exception ex)
            {
                string s = ex.ToString();
            }         
        }
        //________________________________________________________________________________________________
        private void active_listen()
        {
            TcpClient client;
            NetworkStream ns = null;
            byte[] msg = new byte[50000];
            FSM = "init";

            while (!exit)
            {
                ///////////////////////
                switch (FSM)
                {
                    case "init":
                        server = new TcpListener(IPAddress.Any, port);
                        server.Start();
                        FSM = "Waiting_for_Client";
                        break;
                    ///////////////
                    case "Waiting_for_Client":
                        try
                        {
                            client = server.AcceptTcpClient();
                            ns = client.GetStream();
                        }
                        catch (Exception ex)
                        {

                        }
                        FSM = "Reading Data";
                        break;
                    ////////////////////////////
                    case "Reading Data":
                        Int32 k = 0;

                        try
                        {
                            k = ns.Read(msg, 0, msg.Length);   //the same networkstream reads the message sent by the client
                        }
                        catch
                        {

                        }

                        if (k == 0)
                        {
                            FSM = "Waiting_for_Client";
                            break;
                        }
                        else
                        {
                            cmd += Encoding.ASCII.GetString(msg, 0, k);
                            if (cmd.Contains("\r"))
                            {
                                cmd_received = true;
                                FSM = "Waiting_for_user_response";
                                break;
                            }
                        }
                        break;
                    ////////////////////
                    case "Waiting_for_user_response":
                        if (cmd_send)
                        {
                            cmd_send = false;
                            byte[] b = utility.Get_Bytes_from_string(cmd + "\r\n");
                            try
                            {
                                ns.Write(b, 0, b.Length);
                            }
                            catch (Exception ex)
                            {
                                string s = ex.ToString();
                            }
                            cmd = "";
                            FSM = "Waiting_for_Client";
                        }
                        break;
                    ///////////////////////
                    default: break;
                }// switch-case
            }// while(true)
        }
    }//class tcp_client
}// namespace Formation_Charger.Tools
