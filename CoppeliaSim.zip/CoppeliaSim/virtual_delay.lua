
-- Example code
-- require "virtual_delay"
-- virtual_delay.Init(100)
--  if((virtual_delay.TimeOut())==1) then
-----------------------------------------
virtual_delay = {}

delay_reg=0
delay_val=10
--___________________________________________________________________________________________________________________________________
function virtual_delay.Init(time_out) 
    delay_val=time_out
    delay_reg=0 
end
--___________________________________________________________________________________________________________________________________
function virtual_delay.TimeOut()  
    delay_reg=delay_reg+1
    if(delay_reg>delay_val) then
        delay_reg=0
        return 1
    else
        return 0
    end
end
--___________________________________________________________________________________________________________________________________
function virtual_delay.Get_Running_Val()  
     return delay_reg
end 
--___________________________________________________________________________________________________________________________________
function virtual_delay.Get_Compare_Val()  
    return delay_val
end 
--___________________________________________________________________________________________________________________________________

return virtual_delay