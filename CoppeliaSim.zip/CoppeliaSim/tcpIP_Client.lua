tcpIP_Client = {}

local ip_addr="127.0.0.1"
local port=6000
--___________________________________________________________________________________________________________________________________
function tcpIP_Client.Init(ip_address, port_number) 
    ip_addr=ip_address
    port=port_number
end
--___________________________________________________________________________________________________________________________________
function tcpIP_Client.send_receive(cmd,receive_count)  
    local socket=require("socket")
    client=socket.tcp()
    local result=client:connect(ip_addr,port)
    if(result==1) then
        client:send(cmd.."\r")
        local data=client:receive(receive_count)
        if (data==nil) then
            return(nil) -- error
        else
            return data
        end
    end   
end
--___________________________________________________________________________________________________________________________________
 return tcpIP_Client