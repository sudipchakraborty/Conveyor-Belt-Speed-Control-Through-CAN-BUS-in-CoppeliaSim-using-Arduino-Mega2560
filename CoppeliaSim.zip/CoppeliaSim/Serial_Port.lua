Serial_Port = {}

port="COM17"
Baud_Rate=9600
port_handler=0
--___________________________________________________________________________________________________________________________________
function Serial_Port.Open(p, b_rate) 
    port=p
    Baud_Rate=b_rate
    port_handler= sim.serialOpen(port,Baud_Rate)
    if(port_handler==-1) then
        print("Unable to open serial port")
    end
end
--___________________________________________________________________________________________________________________________________
function Serial_Port.send_receive(bfr_send)  
    sim.serialSend(port_handler,bfr_send)
    val=sim.serialRead(port_handler,4,true,'\n',10000)
    return val
end
--___________________________________________________________________________________________________________________________________
function Serial_Port.close() 
    sim.serialClose(port_handler)
end
--___________________________________________________________________________________________________________________________________
 return Serial_Port